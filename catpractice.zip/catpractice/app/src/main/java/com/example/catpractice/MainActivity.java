package com.example.catpractice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.FragmentTransaction;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button frag1,frag2,frag3,n1;
    final String CHANNEL_ID = "Important_mail_channel";
    Button mBtnBigTextNotification;
    NotificationManagerCompat mNotificationManagerCompat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        registerForContextMenu((TextView) findViewById(R.id.t1));

        frag1=(Button)findViewById(R.id.button2);
        frag2=(Button)findViewById(R.id.button3);
        frag3=(Button)findViewById(R.id.button4);
        listener();
        mBtnBigTextNotification = findViewById(R.id.btn_bigtextstyle_notification);




        createNotificationChannel();

        mBtnBigTextNotification.setOnClickListener(this);




        mNotificationManagerCompat = NotificationManagerCompat.from(MainActivity.this);
    }

    public void listener() {
        frag1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction f1 =getSupportFragmentManager().beginTransaction();
                        blankfrag ff1=new blankfrag();
                        f1.replace(R.id.fragment_container,ff1);
                                f1.commit();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater mi = getMenuInflater();
        mi.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater mi = getMenuInflater();
        mi.inflate(R.menu.menu2, menu);

    }

    public void pop(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        MenuInflater mi = getMenuInflater();
        mi.inflate(R.menu.menu3, popup.getMenu());
        popup.show();

    }
    @Override
    public void onClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.btn_bigtextstyle_notification) {
            createBigTextNotification(getString(R.string.bigtext_notification_title), getString(R.string.bigtext_notification_text), 2);
        }
    }
    private void createBigTextNotification(String title, String text, int notificationId) {

        //removes all previously shown notifications.
        mNotificationManagerCompat.cancelAll();

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.lap6);

        NotificationCompat.BigTextStyle style = new NotificationCompat.BigTextStyle().bigText(text + " Biggest Sales Coming Up !! GRAB THE BEST OF THE BESTS")
                //set different title in expanded mode.
                .setBigContentTitle(null)
                //needed if an app sends notification from multiple sources(accounts).
                .setSummaryText("BigTextStyle");


        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle(title)
                .setContentText(text + "Notification : Laptop available at great price Biggest Discount Ever!!")
                //set Big text template
                .setStyle(style)
                //Set the large icon in the notification.
                .setLargeIcon(bitmap)
                .build();

        mNotificationManagerCompat.notify(notificationId, notification);
    }

    private void createNotificationChannel() {

        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            //Channel name
            CharSequence name = "Important_mail_channel";

            //Channel description
            String description = "This channel will show notification only to important people";

            //The importance level you assign to a channel applies to all notifications that you post to it.
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            //Create the NotificationChannel
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);

            //Set channel description
            channel.setDescription(description);

            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


}

